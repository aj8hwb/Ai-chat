package com.aichathub.app.device

import com.aichathub.app.domain.model.AiMemoryBudget
import com.aichathub.app.domain.model.CatalogModel
import com.aichathub.app.domain.model.CompatibilityLevel
import com.aichathub.app.domain.model.DeviceProfile
import com.aichathub.app.domain.model.Recommendation

/** Informational memory analysis bands (NOT enforced as a load gate). */
enum class LoadDecision {
    /** Fits the safe memory budget (≤ 1.0× usable). */
    SAFE,
    /** Uses more than the safe budget but ≤ 1.35× usable. */
    HEAVY,
    /** Exceeds 1.35× usable — labelled NOT_RECOMMENDED, still loadable. */
    BLOCKED
}

/** Hard load-gate result. BLOCK refuses to load the model. */
enum class LoadEligibility { ALLOW, WARN, BLOCK }

data class LoadEligibilityResult(
    val eligibility: LoadEligibility,
    val requiredBytes: Long,
    val usableBytes: Long,
    val measured: Boolean,
    /** Overrides the generic message when the BLOCK reason needs its own wording. */
    private val reasonOverride: String? = null
) {
    val message: String
        get() {
            reasonOverride?.let { return it }
            val reqMb = (requiredBytes / (1024.0 * 1024.0)).round1()
            val usableMb = (usableBytes / (1024.0 * 1024.0)).round1()
            return when (eligibility) {
                LoadEligibility.BLOCK ->
                    "This model actually uses ~$reqMb MB on your device, which is more than the ~$usableMb MB it can safely use. Loading it would likely freeze or crash the phone. Try a lighter model."
                LoadEligibility.WARN ->
                    "This model needs ~$reqMb MB but only ~$usableMb MB is safely available. It may be slow or unstable. Download and try at your own risk."
                LoadEligibility.ALLOW -> "Fits your device's safe memory budget (~$usableMb MB)."
            }
        }
}

/**
 * Evaluates how compatible a model is with the current device state.
 * Pure logic — no Android dependencies, unit-testable.
 */
class CompatibilityEngine {

    private val smartEngine = SmartRecommendationEngine()

    /** Overall compatibility of a model for the current device. */
    fun evaluate(
        model: CatalogModel,
        profile: DeviceProfile,
        budget: AiMemoryBudget,
        measuredMemory: Map<String, Long> = emptyMap()
    ): CompatibilityLevel {
        val memoryScore = memoryScore(model, budget, measuredMemory)
        val ramScore = ramScore(model, profile, measuredMemory)
        val overall = (memoryScore * 2 + ramScore) / 3
        var level = CompatibilityLevel.fromRank(overall)

        // 4 GB RAM ceiling: parameter counts ≥ 1B are memory-hungry on
        // low-RAM devices. They may still run (USABLE) but are never
        // auto-recommended; the user must opt in.
        if (profile.isLowRamDevice && model.parameterCount >= 1_000_000_000L) {
            level = CompatibilityLevel.fromRank(minOf(level.rank, CompatibilityLevel.USABLE.rank))
        }
        return level
    }

    /**
     * Informational memory analysis: how this model's footprint relates to the
     * device's usable AI budget. NOT enforced anywhere — the app never refuses
     * to load a model based on this. The Model Details screen shows the badge
     * and a "may be slow/unstable" warning so the user can decide knowingly.
     *
     *  - ≤ 1.0× usable budget → SAFE.
     *  - ≤ 1.35× usable budget → HEAVY (runs, but may be slow).
     *  - > 1.35× usable budget → BLOCKED (informational label only).
     */
    fun loadDecision(
        model: CatalogModel,
        budget: AiMemoryBudget,
        measuredMemory: Map<String, Long> = emptyMap()
    ): LoadDecision {
        val usable = budget.modelMemoryBytes
        val required = effectiveMemory(model, measuredMemory)
        return when {
            required <= usable * 1.0 -> LoadDecision.SAFE
            required <= usable * 1.35 -> LoadDecision.HEAVY
            else -> LoadDecision.BLOCKED
        }
    }

    /**
     * Hard load gate used by the Chat / Playground / Benchmark entry points.
     *
     * The badges and warnings elsewhere are informational. This is the ONE
     * place a load is refused. Hard BLOCK conditions (never approvable by any
     * warning — spec §2.9/§2.10):
     *  1. The model was MEASURED on this device (real PSS) to need far more
     *     than the safe AI budget.
     *  2. The model's WEIGHTS ALONE exceed the usable budget — no context
     *     size can make that fit, so an estimate-based WARN must not let it
     *     through just because the estimate may be wrong in the user's favour.
     * Without a hard condition we only WARN (estimate-based, the user may
     * still try knowingly).
     */
    fun loadEligibility(
        model: CatalogModel,
        profile: DeviceProfile,
        measuredMemory: Map<String, Long> = emptyMap()
    ): LoadEligibilityResult {
        val budget = MemoryBudgetCalculator.calculate(
            profile,
            modelWeightsBytes = model.fileSizeBytes,
            contextLength = model.contextLength,
            parameterCount = model.parameterCount
        )
        val usable = budget.modelMemoryBytes
        val measured = measuredMemory[model.id]
        val required = measured ?: model.estimatedMemoryBytes
        val weightsAloneOverBudget = model.fileSizeBytes > 0 && model.fileSizeBytes > usable
        val eligibility = when {
            required <= usable * 1.35 -> LoadEligibility.ALLOW
            measured != null -> LoadEligibility.BLOCK
            weightsAloneOverBudget -> LoadEligibility.BLOCK
            else -> LoadEligibility.WARN
        }
        val weightsBlockMessage = if (eligibility == LoadEligibility.BLOCK && weightsAloneOverBudget && measured == null) {
            val modelGb = (model.fileSizeBytes / (1024.0 * 1024.0 * 1024.0)).round1()
            val usableMb = (usable / (1024.0 * 1024.0)).round1()
            "This model's file alone is ~${modelGb} GB, more than the ~$usableMb MB that can safely be used " +
                "for AI on this device. Even the smallest context cannot make it fit. Try a lighter model."
        } else null
        return LoadEligibilityResult(
            eligibility = eligibility,
            requiredBytes = required,
            usableBytes = usable,
            measured = measured != null,
            reasonOverride = weightsBlockMessage
        )
    }

    /**
     * Returns a list of recommendations for all catalog models, ranked.
     * Static device-analysis is combined with model characteristics.
     *
     * @param measuredMemory real PSS bytes measured on this device for some
     *   models; when present it overrides the catalog's [CatalogModel.estimatedMemoryBytes].
     */
    fun recommendAll(
        models: List<CatalogModel>,
        profile: DeviceProfile,
        budget: AiMemoryBudget,
        measuredMemory: Map<String, Long> = emptyMap()
    ): List<Recommendation> =
        models
            .map { model ->
                val level = evaluate(model, profile, budget, measuredMemory)
                Recommendation(
                    model = model,
                    level = level,
                    score = level.rank,
                    reason = reasonFor(model, level, budget, measuredMemory),
                    quantizationNote = quantizationNote(model, budget, measuredMemory)
                )
            }
            .sortedWith(
                compareByDescending<Recommendation> { it.level.rank }
                    .thenBy { it.model.fileSizeBytes }
            )

    /**
     * Enhanced recommendation using [SmartRecommendationEngine].
     * Returns richer scoring data than [recommendAll] while preserving
     * backward compatibility — callers that don't need the extra data
     * can keep using [recommendAll].
     *
     * @param thermalStatus  Current device thermal throttle level.
     * @param batteryLevel   0..100 percentage, or -1 if unknown.
     * @param measuredPss    Real measured PSS in bytes per model id.
     * @param pastBenchmarks Map of model id → tokens-per-second.
     * @param mode           What the user cares about most.
     */
    fun smartRecommend(
        models: List<CatalogModel>,
        profile: DeviceProfile,
        budget: AiMemoryBudget,
        mode: RecommendationMode = RecommendationMode.BEST_BALANCE,
        thermalStatus: ThermalStatus = ThermalStatus.NONE,
        batteryLevel: Int = -1,
        measuredPss: Map<String, Long> = emptyMap(),
        pastBenchmarks: Map<String, Float> = emptyMap()
    ): List<SmartRecommendation> =
        smartEngine.recommendAll(
            models = models,
            profile = profile,
            budget = budget,
            mode = mode,
            thermalStatus = thermalStatus,
            batteryLevel = batteryLevel,
            measuredPss = measuredPss,
            pastBenchmarks = pastBenchmarks
        )

    /**
     * Memory headroom against the SAME budget the load preflight uses
     * ([AiMemoryBudget.modelMemoryBytes]). The compatibility badge, the
     * "Download Anyway" warning and the actual load gate ([loadDecision])
     * therefore always agree — a model can never be recommended on screen
     * and then refused at load time.
     */
    private fun memoryScore(model: CatalogModel, budget: AiMemoryBudget, measuredMemory: Map<String, Long>): Int {
        val usable = budget.modelMemoryBytes
        val required = effectiveMemory(model, measuredMemory)
        return when {
            required <= usable * 0.6 -> 5
            required <= usable * 0.8 -> 4
            required <= usable * 1.0 -> 3
            required <= usable * 1.35 -> 2
            else -> 1
        }
    }

    private fun ramScore(model: CatalogModel, profile: DeviceProfile, measuredMemory: Map<String, Long>): Int {
        // Compare the model's expected memory footprint against total device RAM.
        val totalGb = profile.totalRamGb.toDouble()
        val requiredGb = effectiveMemory(model, measuredMemory) / (1024.0 * 1024.0 * 1024.0)
        return when {
            requiredGb <= totalGb * 0.6 -> 5
            requiredGb <= totalGb * 0.75 -> 4
            requiredGb <= totalGb * 0.9 -> 3
            requiredGb <= totalGb * 1.1 -> 2
            else -> 1
        }
    }

    /**
     * Real measured PSS wins over the catalog estimate when available — a model
     * measured to use far more (or far less) memory than estimated must be
     * scored on what actually happens on THIS device.
     */
    private fun effectiveMemory(model: CatalogModel, measuredMemory: Map<String, Long>): Long =
        measuredMemory[model.id] ?: model.estimatedMemoryBytes

    /**
     * Data-backed reason: the message quotes the real numbers (estimated or
     * measured on THIS device) that produced the level, not just a slogan.
     */
    private fun reasonFor(
        model: CatalogModel,
        level: CompatibilityLevel,
        budget: AiMemoryBudget,
        measuredMemory: Map<String, Long>
    ): String {
        val required = effectiveMemory(model, measuredMemory)
        val requiredMb = (required / (1024.0 * 1024.0)).round1()
        val usableMb = (budget.modelMemoryBytes / (1024.0 * 1024.0)).round1()
        val measured = measuredMemory[model.id]
        val source = if (measured != null) "measured on your device" else "estimated"
        return when (level) {
            CompatibilityLevel.EXCELLENT ->
                "Fits your memory budget with room to spare. (~$requiredMb MB $source vs ${usableMb}MB safe budget.)"
            CompatibilityLevel.RECOMMENDED ->
                "This model is well suited to your device. (~$requiredMb MB $source vs ${usableMb}MB safe budget.)"
            CompatibilityLevel.USABLE ->
                "Will run, but performance may be limited. (~$requiredMb MB $source vs ${usableMb}MB safe budget.)"
            CompatibilityLevel.HEAVY ->
                "Uses more memory than is safely available right now. (~$requiredMb MB $source vs ${usableMb}MB safe budget.)"
            CompatibilityLevel.NOT_RECOMMENDED ->
                "Too heavy for your current device memory. (~$requiredMb MB $source vs ${usableMb}MB safe budget.)"
        }
    }

    private fun quantizationNote(model: CatalogModel, budget: AiMemoryBudget, measuredMemory: Map<String, Long>): String? {
        val ratio = effectiveMemory(model, measuredMemory).toDouble() / budget.modelMemoryBytes.toDouble()
        return if (ratio > 1.0) {
            "A smaller quantization or a lighter model is recommended."
        } else null
    }
}

private fun Double.round1(): String = (kotlin.math.round(this * 10) / 10).toString()
